<div>
    <button wire:click="increment">+</button>
    <h1>{{ $count }}</h1>
    <h1>{{ $coba }}</h1>
</div>