<div style="display: none;" id="loading" class="fixed inset-0 flex justify-center items-center w-full h-[100vh] bg-green-600 bg-opacity-50">
    <div class="relative flex justify-center items-center">
        <div class="absolute animate-spin rounded-full h-32 w-32 border-t-4 border-b-4 border-green-600"></div>
        {{-- <img src="https://www.svgrepo.com/show/509001/avatar-thinking-9.svg" class="rounded-full h-28 w-28"> --}}
        <img src="/img/logokecil.png" class="rounded-full h-28 w-28">
    </div>
</div>